import express from 'express';
import { getPostList} from '../Controllers/PostController.js';
import { authenticateToken } from '../Controllers/LoginController.js'


const router = express.Router();

router.get('/',authenticateToken,getPostList); 

export default router;