import express from 'express';
import { authenticateUser,token,logout} from '../Controllers/LoginController.js';

const router = express.Router();

router.post('/',authenticateUser); 
router.post('/token',token); 
router.post('/logout',logout); 

export default router;