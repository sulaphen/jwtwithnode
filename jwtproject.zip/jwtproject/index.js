import express from 'express';
import bodyParser from 'body-parser';

// Routes
import postRoutes from './Routes/PostRoutes.js'
import loginRoutes from './Routes/LoginRoutes.js';

const app = express();
// limit image size
app.use(bodyParser.json({limit : "30mb", extended : true}));
// urlencoded max limit
app.use(bodyParser.urlencoded({limit : "30mb", extended : true}));

app.listen(3000);

app.use('/',loginRoutes);
app.use('/login',loginRoutes);
app.use('/posts',postRoutes);


