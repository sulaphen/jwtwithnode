export const getPostList =  (req,res) => {
    try {
        const allPosts = [
                            { 
                                'name' : 'sulaphen',
                                'title' : 'Sulaphen Post'
                            },
                            { 
                                'name' : 'Artahy',
                                'title' : 'Artahy Post'
                            },
                            { 
                                'name' : 'Yuvan',
                                'title' : 'Yuvan Post'
                            },
                        
                        ]
        res.status(200).json(allPosts);
    } catch (error) {
        res.status(409).json({message:error});
    }
}