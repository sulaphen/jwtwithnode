import dotenv from 'dotenv';
dotenv.config();

import jwt from 'jsonwebtoken';

let refreshTokens = [];

export const authenticateUser =  (req,res) => {
    try {
        const username = req.body.username;
        // make authenticatation via db here
        const user= {'name' : username};

        const accessToken = generateAccessToken(user)
        const refreshToken = jwt.sign(user,process.env.REFRESH_TOKEN)

        refreshTokens.push(refreshToken)

        res.status(200).json({'accesstoken' : accessToken, 'refreshToken' : refreshToken});

    } catch (error) {
        res.status(409).json({message:error.message});
    }
}

function generateAccessToken(user){
    return jwt.sign(user,process.env.ACCESS_TOKEN_SECRETE,{expiresIn: '15m' })
}

export const authenticateToken =  (req,res,next) => {
    try {
        const authHeader = req.headers['authorization'];
        const token      = authHeader && authHeader.split(' ')[1]

        if(token == null) return res.status(401).json({'message' : 'un authorized 401'})

        jwt.verify(token,process.env.ACCESS_TOKEN_SECRETE,(err,user) => {
            if(err) return res.status(403).json({'message' : 'un authorized 403'+err})
            
            req.user = user
            next()
        })
    } catch (error) {
        res.status(409).json({message:error.message});
    }
}

export const token =  (req,res) => {
    try {
        const refreshToken = req.body.token
        if(refreshToken == null) return res.status(401).json({ 'message' : '401 unauthorized'})
        if(!refreshTokens.includes(refreshToken)) return res.status(403).json({ 'message' : '403 unauthorized'})

        jwt.verify(refreshToken,process.env.REFRESH_TOKEN,(err,user) => {
            if(err) return res.status(403).json({'message' : '403 unauthorized'})
            const accessToken = generateAccessToken({'name':user.name})
            res.status(200).json({'accesstoken' : accessToken});
        })
    } catch (error) {
        res.status(409).json({message:error.message});
    }
}

export const logout =  (req,res) => {
    try {
        refreshTokens = refreshTokens.filter(token  => token !== req.body.token)
        refreshTokens = [];
        res.status(209).json({message:'successfully logout'});
    } catch (error) {
        res.status(409).json({message:error.message});
    }
}